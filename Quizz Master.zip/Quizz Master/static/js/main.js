document.addEventListener('DOMContentLoaded', function() {
  // Theme toggle functionality
  const themeToggle = document.querySelector('.mode-toggle');
  const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
  
  if (themeToggle) {
    themeToggle.addEventListener('click', function() {
      if (prefersDarkScheme.matches) {
        document.body.classList.toggle('light-mode');
        const theme = document.body.classList.contains('light-mode') ? 'light' : 'dark';
        localStorage.setItem('theme', theme);
      } else {
        document.body.classList.toggle('dark-mode');
        const theme = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
        localStorage.setItem('theme', theme);
      }
      
      updateThemeIcon();
    });
  }
  
  // Apply saved theme on page load
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    if (prefersDarkScheme.matches) {
      if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
      }
    } else {
      if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
      }
    }
  }
  
  // Update theme icon based on current mode
  function updateThemeIcon() {
    const icon = document.querySelector('.mode-toggle i');
    if (!icon) return;
    
    const isDark = (prefersDarkScheme.matches && !document.body.classList.contains('light-mode')) || 
                 (!prefersDarkScheme.matches && document.body.classList.contains('dark-mode'));
    
    if (isDark) {
      icon.className = 'fas fa-sun';
    } else {
      icon.className = 'fas fa-moon';
    }
  }
  
  updateThemeIcon();
  
  // Mobile navigation toggle
  const navbarToggle = document.querySelector('.navbar-toggle');
  const navbarCollapse = document.querySelector('.navbar-collapse');
  const navbarOverlay = document.querySelector('.navbar-overlay');
  
  if (navbarToggle && navbarCollapse && navbarOverlay) {
    navbarToggle.addEventListener('click', function() {
      navbarCollapse.classList.toggle('show');
      navbarOverlay.classList.toggle('show');
      document.body.classList.toggle('nav-open');
    });
    
    navbarOverlay.addEventListener('click', function() {
      navbarCollapse.classList.remove('show');
      navbarOverlay.classList.remove('show');
      document.body.classList.remove('nav-open');
    });
  }
  
  // Header scroll effect
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 10) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }
  
  // Form validation
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      
      form.classList.add('was-validated');
    }, false);
  });
  
  // Auto-dismiss alerts
  const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
  alerts.forEach(alert => {
    setTimeout(() => {
      const fadeEffect = setInterval(() => {
        if (!alert.style.opacity) {
          alert.style.opacity = 1;
        }
        if (alert.style.opacity > 0) {
          alert.style.opacity -= 0.1;
        } else {
          clearInterval(fadeEffect);
          alert.style.display = 'none';
        }
      }, 50);
    }, 5000);
  });
  
  // Animate elements when they come into view
  const animateElements = document.querySelectorAll('.animate-on-scroll');
  
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };
  
  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  animateElements.forEach(element => {
    observer.observe(element);
  });
  
  // Toast notifications
  const toastShowTriggers = document.querySelectorAll('[data-toggle="toast"]');
  
  toastShowTriggers.forEach(trigger => {
    trigger.addEventListener('click', () => {
      const targetId = trigger.getAttribute('data-target');
      const toastElement = document.querySelector(targetId);
      
      if (toastElement) {
        toastElement.classList.add('show');
        
        setTimeout(() => {
          toastElement.classList.remove('show');
        }, 5000);
      }
    });
  });
  
  // Initialize dropdowns
  const dropdownToggleElements = document.querySelectorAll('.dropdown-toggle');
  
  dropdownToggleElements.forEach(toggleEl => {
    toggleEl.addEventListener('click', (e) => {
      e.preventDefault();
      const dropdown = toggleEl.nextElementSibling;
      
      // Close all other open dropdowns
      document.querySelectorAll('.dropdown-menu.show').forEach(openDropdown => {
        if (openDropdown !== dropdown) {
          openDropdown.classList.remove('show');
        }
      });
      
      dropdown.classList.toggle('show');
    });
  });
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.matches('.dropdown-toggle') && !e.target.closest('.dropdown-menu')) {
      document.querySelectorAll('.dropdown-menu.show').forEach(openDropdown => {
        openDropdown.classList.remove('show');
      });
    }
  });
  
  // Filter functionality for item list
  const filterForm = document.getElementById('filter-form');
  if (filterForm) {
    const inputs = filterForm.querySelectorAll('select, input');
    inputs.forEach(input => {
      input.addEventListener('change', () => {
        filterForm.submit();
      });
    });
  }
});