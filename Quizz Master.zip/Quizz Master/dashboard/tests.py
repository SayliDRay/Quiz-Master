from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from .models import Item


class ItemModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        
        self.item = Item.objects.create(
            title='Test Item',
            description='Test Description',
            user=self.user,
            status='pending',
            priority='medium'
        )
    
    def test_item_creation(self):
        """Test item creation and string representation"""
        self.assertEqual(self.item.title, 'Test Item')
        self.assertEqual(str(self.item), 'Test Item')


class DashboardViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        
        self.client.login(username='testuser', password='testpassword123')
    
    def test_dashboard_home(self):
        """Test dashboard home view loads correctly"""
        response = self.client.get(reverse('dashboard:home'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'dashboard/home.html')