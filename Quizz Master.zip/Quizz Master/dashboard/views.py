from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Avg
from quiz.models import Quiz, QuizAttempt


@login_required
def home(request):
    """Dashboard home view with statistics"""
    # Get all active quizzes
    active_quizzes = Quiz.objects.filter(is_active=True)
    
    # Get user's quiz attempts with related fields
    user_attempts = QuizAttempt.objects.filter(user=request.user).select_related('quiz')
    
    # Get completed quizzes
    completed_quizzes = user_attempts.filter(completed_at__isnull=False)
    
    # Get quiz statistics
    quiz_stats = {
        'total_quizzes': active_quizzes.count(),
        'completed_quizzes': completed_quizzes.count(),
        'passed_quizzes': completed_quizzes.filter(is_passed=True).count(),
        'average_score': completed_quizzes.aggregate(avg_score=Avg('score'))['avg_score'] or 0
    }
    
    # Get recent quiz attempts with all necessary related fields
    recent_attempts = user_attempts.select_related('quiz').order_by('-started_at')[:5]
    
    context = {
        'quiz_stats': quiz_stats,
        'recent_attempts': recent_attempts,
        'active_quizzes': active_quizzes,
    }
    
    return render(request, 'dashboard/home.html', context)


@login_required
def quiz_list(request):
    """View to list all active quizzes"""
    # Get filter parameters
    search_query = request.GET.get('search', '')
    
    # Start with all active quizzes
    quizzes = Quiz.objects.filter(is_active=True)
    
    # Apply search filter
    if search_query:
        quizzes = quizzes.filter(title__icontains=search_query)
    
    # Get user's attempts for these quizzes
    user_attempts = QuizAttempt.objects.filter(
        user=request.user,
        quiz__in=quizzes
    ).select_related('quiz')
    
    # Create a dictionary of attempts for easy lookup
    attempts_dict = {attempt.quiz_id: attempt for attempt in user_attempts}
    
    context = {
        'quizzes': quizzes,
        'attempts_dict': attempts_dict,
        'search_query': search_query,
    }
    
    return render(request, 'dashboard/quiz_list.html', context)


@login_required
def quiz_detail(request, pk):
    """View to show quiz details"""
    quiz = get_object_or_404(Quiz, pk=pk, is_active=True)
    
    # Get user's attempts for this quiz
    attempts = QuizAttempt.objects.filter(
        user=request.user,
        quiz=quiz
    ).order_by('-started_at')
    
    context = {
        'quiz': quiz,
        'attempts': attempts,
    }
    
    return render(request, 'dashboard/quiz_detail.html', context)