from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db.models import Count
from .models import Quiz, Question, Choice, QuizAttempt, UserAnswer


@login_required
def quiz_list(request):
    """View to list all active quizzes"""
    quizzes = Quiz.objects.filter(is_active=True)
    return render(request, 'quiz/quiz_list.html', {'quizzes': quizzes})


@login_required
def quiz_detail(request, pk):
    """View to show quiz details and start button"""
    quiz = get_object_or_404(Quiz, pk=pk, is_active=True)
    
    # Check if user has already attempted this quiz
    previous_attempt = QuizAttempt.objects.filter(
        user=request.user,
        quiz=quiz,
        completed_at__isnull=False
    ).first()
    
    context = {
        'quiz': quiz,
        'previous_attempt': previous_attempt,
    }
    return render(request, 'quiz/quiz_detail.html', context)


@login_required
def start_quiz(request, pk):
    """View to start a new quiz attempt"""
    quiz = get_object_or_404(Quiz, pk=pk, is_active=True)
    
    # Check if user has an incomplete attempt
    incomplete_attempt = QuizAttempt.objects.filter(
        user=request.user,
        quiz=quiz,
        completed_at__isnull=True
    ).first()
    
    if incomplete_attempt:
        return redirect('quiz:take_quiz', attempt_id=incomplete_attempt.id)
    
    # Create new attempt
    attempt = QuizAttempt.objects.create(user=request.user, quiz=quiz)
    return redirect('quiz:take_quiz', attempt_id=attempt.id)


@login_required
def take_quiz(request, attempt_id):
    """View to take the quiz"""
    attempt = get_object_or_404(QuizAttempt, id=attempt_id, user=request.user)
    
    if attempt.completed_at:
        messages.warning(request, 'You have already completed this quiz.')
        return redirect('quiz:quiz_detail', pk=attempt.quiz.id)
    
    # Get current question
    answered_questions = attempt.answers.values_list('question_id', flat=True)
    current_question = Question.objects.filter(
        quiz=attempt.quiz
    ).exclude(
        id__in=answered_questions
    ).first()
    
    if not current_question:
        # All questions answered, calculate score
        correct_answers = attempt.answers.filter(is_correct=True).count()
        total_questions = attempt.quiz.questions.count()
        score = int((correct_answers / total_questions) * 100)
        
        attempt.completed_at = timezone.now()
        attempt.score = score
        attempt.is_passed = score >= attempt.quiz.passing_score
        attempt.save()
        
        messages.success(request, f'Quiz completed! Your score: {score}%')
        return redirect('quiz:quiz_result', attempt_id=attempt.id)
    
    if request.method == 'POST':
        choice_id = request.POST.get('choice')
        if choice_id:
            choice = get_object_or_404(Choice, id=choice_id, question=current_question)
            UserAnswer.objects.create(
                attempt=attempt,
                question=current_question,
                selected_choice=choice,
                is_correct=choice.is_correct
            )
            return redirect('quiz:take_quiz', attempt_id=attempt.id)
    
    context = {
        'attempt': attempt,
        'question': current_question,
        'choices': current_question.choices.all(),
        'progress': (len(answered_questions) / attempt.quiz.questions.count()) * 100
    }
    return render(request, 'quiz/take_quiz.html', context)


@login_required
def quiz_result(request, attempt_id):
    """View to show quiz results"""
    attempt = get_object_or_404(QuizAttempt, id=attempt_id, user=request.user)
    
    if not attempt.completed_at:
        return redirect('quiz:take_quiz', attempt_id=attempt.id)
    
    context = {
        'attempt': attempt,
        'answers': attempt.answers.select_related('question', 'selected_choice').all()
    }
    return render(request, 'quiz/quiz_result.html', context)
