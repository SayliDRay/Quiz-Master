from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import Profile

class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'Profile'

class CustomUserAdmin(UserAdmin):
    inlines = (ProfileInline,)
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')

admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'is_verified', 'date_joined')
    list_filter = ('is_verified', 'gender', 'date_joined')
    search_fields = ('user__username', 'user__email', 'phone_number', 'address')
    readonly_fields = ('date_joined', 'last_login_ip')
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'image', 'bio')
        }),
        ('Contact Information', {
            'fields': ('phone_number', 'address')
        }),
        ('Personal Information', {
            'fields': ('gender', 'birth_date')
        }),
        ('Account Status', {
            'fields': ('is_verified', 'last_login_ip', 'date_joined')
        }),
    )