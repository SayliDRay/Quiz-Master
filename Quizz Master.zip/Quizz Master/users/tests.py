from django.test import TestCase
from django.contrib.auth.models import User
from .models import Profile


class ProfileModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
    
    def test_profile_creation(self):
        """Test that a profile is created for each new user"""
        self.assertTrue(Profile.objects.filter(user=self.user).exists())
        
    def test_profile_str(self):
        """Test the string representation of a profile"""
        profile = Profile.objects.get(user=self.user)
        self.assertEqual(str(profile), 'testuser Profile')